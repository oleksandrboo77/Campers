"use client";

import { useState } from "react";
import styles from "./Filter.module.css";
import { useCampersStore } from "../../store/store";
import type { BodyType } from "../../lib/types";

export default function Filter() {
  const { setFilters, resetAndFetch } = useCampersStore();

  const [location, setLocation] = useState("");
  const [bodyType, setBodyType] = useState<BodyType>(null);
  const [equipment, setEquipment] = useState<string[]>([]);

  const toggleEquipment = (value: string) => {
    setEquipment((prev) =>
      prev.includes(value)
        ? prev.filter((item) => item !== value)
        : [...prev, value]
    );
  };

  const handleSearch = () => {
    setFilters({ location, bodyType, equipment });
    resetAndFetch();
  };

  return (
    <aside className={styles.sidebar}>
      <div className={styles.block}>
        <p className={styles.label}>Location</p>
        <input
          type="text"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          placeholder="City"
          className={styles.input}
        />
      </div>

      <div className={styles.block}>
        <p className={styles.title}>Vehicle equipment</p>
        <div className={styles.chips}>
          <button
            type="button"
            className={
              equipment.includes("AC") ? styles.chipActive : styles.chip
            }
            onClick={() => toggleEquipment("AC")}
          >
            AC
          </button>
          <button
            type="button"
            className={
              equipment.includes("kitchen") ? styles.chipActive : styles.chip
            }
            onClick={() => toggleEquipment("kitchen")}
          >
            Kitchen
          </button>
          <button
            type="button"
            className={
              equipment.includes("bathroom") ? styles.chipActive : styles.chip
            }
            onClick={() => toggleEquipment("bathroom")}
          >
            Bathroom
          </button>
          <button
            type="button"
            className={
              equipment.includes("TV") ? styles.chipActive : styles.chip
            }
            onClick={() => toggleEquipment("TV")}
          >
            TV
          </button>
        </div>
      </div>

      <div className={styles.block}>
        <p className={styles.title}>Vehicle type</p>
        <div className={styles.types}>
          <button
            type="button"
            className={
              bodyType === "panelTruck" ? styles.typeActive : styles.type
            }
            onClick={() => setBodyType("panelTruck")}
          >
            Van
          </button>
          <button
            type="button"
            className={
              bodyType === "fullyIntegrated" ? styles.typeActive : styles.type
            }
            onClick={() => setBodyType("fullyIntegrated")}
          >
            Fully Integrated
          </button>
          <button
            type="button"
            className={bodyType === "alcove" ? styles.typeActive : styles.type}
            onClick={() => setBodyType("alcove")}
          >
            Alcove
          </button>
        </div>
      </div>

      <button
        type="button"
        className={styles.searchButton}
        onClick={handleSearch}
      >
        Search
      </button>
    </aside>
  );
}
